To generate output files run your shell using the provided input
For example: shell_jr < public01.in > my_results   
Then compare my_results against the provided output.
