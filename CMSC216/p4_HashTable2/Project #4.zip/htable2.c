/* Name: Ben Aronosn
 * UID: 113548802
 * ID: baronson
 * CMSC216 0301
 * Project 4
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h> /* might not need this */
#include <sysexits.h> /*might not need this */
#include "htable.h"

unsigned int hash_code(const char *str);


/******************** helper method(s) ********************/

/* This function returns the position (index) of the key in the table.
   It will return the variable 'pos' which will be initialized at -1.
   If this function returns -1, it implies that key was NOT found 
   in the table. If it returns anything other than -1, it implies 
   that it was FOUND and gives what index it was at */ 
static int find_key(const Table *table, const char *key) {
  Bucket *curr = NULL, *buck = NULL;
  int found = 0, size = 0;

  size = table->table_size;

  if(table->buckets[hash_code(key)%size] != NULL) {
    curr == table->buckets[hash_code(key)%size];

    while(curr != NULL || found == 1) {
      if(strcmp(curr->key, key) != 0) {
	buck = curr;
	curr = curr->next;
      } else {
	found = 1;
      }
    }

    
  }
  
  return found; 
}

/*quick little function to indicate that the key was found, returns 1 or 0 */
static int key_found( int findkey_rslt ) {
  if(findkey_rslt == 1) {
    return SUCCESS;
  }
  return FAILURE;
}


/* function to help insert the key/value node into the bucket */
static int insert(Table *table, const char *key, void *value,
		  Bucket **curr, int pos,int found) {
  Bucket *current = NULL, *prev = NULL, *new_item = NULL;

  if(key_found(found) == 1) {
    /*key in table */    
    current = table->buckets[pos];
    prev = NULL;

    while( current->key != NULL || strcmp(current->key, key) != 0) {
      prev = current;
      current = current->next;
    }

    /* once it gets to here, update the value but not the key */
    current->value = value;

    /* then free the previous value with free_value */
    if(table->free_value != NULL && prev->value != NULL) {
      table->free_value(prev->value); /* how does this work */
    }
    return SUCCESS;
  } else {
    /**************************
     * key_found(found) == 0; *
     * AKA  key is not found   *
     **************************/
    
    current = table->buckets[pos];
    
    new_item = malloc(sizeof(Bucket));
    if(new_item == NULL) {
      return 0;
    }

    new_item->key = malloc(strlen(key) + 1);
    
    strcpy(new_item->key, key);
    new_item->value = value;
    new_item->next = current;
  
    if(prev == NULL) {
      current = new_item;
    } else {
      prev->next = new_item;
    }

    return SUCCESS;
  }
}

/* delete */
static int delete(Table *table, const char *key, int pos) {
  Bucket *curr, *prev;

  curr = table->buckets[pos]; /* head at index 'pos' */
  prev = NULL;
  
  while(curr != NULL && strcmp(curr->key, key) != 0) {
    prev = curr;
    curr = curr->next;
  }
  if(curr == NULL) {
    return FAILURE; /*not found */
  }
  
  /* this before the free part? */
  if(prev != NULL) {
    prev->next = curr->next;
  } else {
    table->buckets[pos] = curr->next; /* deleted first item */
  }

  free(curr->key);
  if(curr->value != NULL && table->free_value != NULL) {
    table->free_value(curr->value); /* how does this work */
  }
  free(curr); /* need this after? */
  
  return SUCCESS;
}




/************ END helper methods END ********************/


/* create a table */
int create_table(Table **table, int table_size, void (*free_value)(void *)) {
  int i = 0, size = 0; 

   /* if table is NULL or table size is 0 */
  if(table == NULL || table_size  == 0) {
    return FAILURE;
  }

  
  (*table) = malloc(sizeof(Table));
  if(table == NULL) {
    return FAILURE;
  }
  
  (*table)->buckets = calloc(table_size, sizeof(Bucket));
  if((*table)->buckets == NULL) {
    return FAILURE;
  }

  
  (*table)->key_count = 0;
  (*table)->table_size = table_size;
  size = (*table)->table_size;

  /* is this correct? */
  for(i = 0; i < size; i++) {
    /* (*table)->buckets[i] = malloc(sizeof(Bucket)); */
    (*table)->buckets[i] = NULL;
  }

  if(free_value != NULL) {
    (*table)->free_value = free_value;
  } else {
    /* only need to free memory from Key */
    (*table)->free_value = NULL;
  }

  return SUCCESS;
}


/* insert key/val pair into table */
int put(Table *table, const char *key, void *value) {
  char *k2;
  int pos = 0, size = 0;

  
  if(table == NULL || key == NULL) {
    return FAILURE;
  }

  size = table->table_size;
  pos = hash_code(key) % size;

      
  if( find_key(table, key) == 0) {
    /* key does not exist in the table */

    table->buckets[pos] = malloc(sizeof(Bucket));
    table->buckets[pos]->key = malloc(strlen(key) + 1);
    
    k2 = malloc(strlen(key) + 1);
    strcpy(k2, key);

    /* use 0 for the 'found' parameter because key was NOT found */
    if(insert(table, k2, value, pos, 0) == 1) {
      table->key_count++;
      return SUCCESS;
    }
  } else {
    /* key DOES exist in the table. */

    
    if(insert(table, key, value, pos, 1) == 1) {
      table->key_count++;
      return SUCCESS;
    }
  }
  return FAILURE;
}




/* removes key/val pair if key is in table */
int remove_entry(Table *table, const char *key) {
  int find = 0, size = 0, pos = 0;
  
  if(table == NULL || key == NULL) {
    return FAILURE;
  }
  
  size = table->table_size;
  pos = hash_code(key) % size;
  find = find_key(table, key);

  if(key_found(find) == 1) {
    /* key is in table - remove key/val pair */
    
    if(delete(table, key, pos) == 1) {
      table->key_count--;
      return SUCCESS;
    } else {
      return FAILURE;
    }
  } 

  /* ELSE: key is not in table */
  
  return FAILURE; /* default return success or failure?? */ 
}






/* removes the list with each bucket, sets it to NULL */
int clear_table(Table *table) {
  int i = 0;

  if(table == NULL) {
    return FAILURE;
  }
  
  for( ; i < table->table_size; i++) {
    while(table->buckets[i] != NULL) {
      free(table->buckets[i]->key);
      table->free_value(table->buckets[i]->value);
      
      table->buckets[i] = table->buckets[i]->next;
    }
    table->buckets[i] = NULL;
    
  }
  table->key_count = 0;
  
  return SUCCESS;
}



/* frees memory in the table */
int destroy_table(Table *table) {
  Bucket *curr = NULL;
  int i = 0;
  
  if(table == NULL) {
    return FAILURE;
  }

  for( ; i < table->table_size; i++) {
   
    
    if(table->buckets[i] != NULL) {
      curr = table->buckets[i];
    }

    while(curr != NULL) {
      free(curr->key);
      if(table->free_value != NULL) {
	table->free_value(curr->value);
      }
      free(curr);
    
      curr = curr->next;
    }
  }

  free(table->buckets);
  free(table);
  
  return SUCCESS;
}



/* copies value pointer into value out parameter if key is found */ 
int get_value(const Table *table, const char *key, void **value) {
  int find = 0, size = 0, pos = 0;
  
  if(table == NULL || key == NULL) {
    return FAILURE;
  }
  size = table->table_size;
  pos = hash_code(key) % size; 
  find = find_key(table, key);
  
  if(key_found(find) == 1) {
    /* copy value ptr into value out parameter */

    (*value) = table->buckets[pos]->value; 
    
    return SUCCESS;
  } else {
    /*key was not found in the table */

    (*value) = NULL; /* this can NOT be correct... */
    
    return FAILURE;
  }
}

/* returns # of keys. return FAILURE if table is NULL */
int get_key_count(const Table *table) {

  if(table == NULL) {
    /* "the function will fail" ? */
    return FAILURE;
  }
  return table->key_count;
}

/* checks if the table is empty - returns SUCCESS if it is*/
int is_empty(const Table *table) {

  if(table == NULL || table->key_count == 0) {
    return SUCCESS;
  }
  return 0;
}

/* returns the table size. return FAILURE if NULL */
int get_table_size(const Table *table) {

  if(table == NULL) {
    return FAILURE;
  }
  return table->table_size;
}


/* 
 * Do not modify this hash_code function.
 * Leave this function at the end of the file.
 * Do not add a prototype to the htable.h file
 * for this function.
 *
 */

unsigned int hash_code(const char *str) {
   unsigned int code;

   for (code = 0; *str; str++) {
      code ^= ((code << 3) | (code >> 29)) + (*str);
   }

   return code; 
}


/* in PUT */
/* malloc-ing *******************************/
  /* table->buckets->key = malloc(strlen(key) + 1);
  if(table->buckets->key == NULL) {
    return FAILURE;
  }
  
  table->buckets.value = malloc(sizeof(value));
  if(table->buckets.value == NULL) {
    return FAILURE;
  }
  
  k2 = malloc(strlen(key) + 1);
  if(k2 == NULL) {
    return FAILURE;
  }
  strcpy(k2, key);*/
  /* end malloc-ing **************************/
