/* Name: Ben Aronosn
 * UID: 113548802
 * ID: baronson
 * CMSC216 0301
 * Project 4
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "htable.h"

unsigned int hash_code(const char *str);


/* create a table */
int create_table(Table **table, int table_size, void (*free_value)(void *)) {
  int i = 0, size = 0; 

  if(table == NULL || table_size  == 0) {
    return FAILURE;
  }

  
  (*table) = malloc(sizeof(Table));
  if(table == NULL) {
    return FAILURE;
  }
  
  (*table)->buckets = calloc(table_size, sizeof(Bucket));
  if((*table)->buckets == NULL) {
    return FAILURE;
  }
  
  (*table)->key_count = 0;
  (*table)->table_size = table_size;
  size = (*table)->table_size;

 for(i = 0; i < size; i++) {
    (*table)->buckets[i] = NULL;
  }

  if(free_value != NULL) {
    (*table)->free_value = free_value;
  } else {
    (*table)->free_value = NULL;
  }

  return SUCCESS;
}


int destroy_table(Table *table) {

  if(table == NULL) {
    return FAILURE;
  }
  
  /* this can call clear_table as it does the same thing:
   * 1. goes through array 
   * 2. if the first bucket is not null, assigns Bucket 'current' to it
   * 3. goes through that linked list freeing and setting to null each 
   *     property of that Bucket
   * 4. sets key count to 0 and each list to NULL
   */
  clear_table(table);

  free(table->buckets);
  free(table);
  
  return SUCCESS;
}

/* puts bucket in the table */
int put(Table *table, const char *key, void *value) {
  Bucket *current = NULL, *new_b = NULL;
  int size = 0, found = 0;
  char *k2;
  
  if(table == NULL || key == NULL) {
    return FAILURE;
  }

  size = table->table_size;

  /***** find ******/
  if(table->buckets[hash_code(key) % size] != NULL) {
    current = table->buckets[hash_code(key) % size];

    while(current != NULL) {
      if(strcmp(current->key, key) == 0) {
	found = 1; /* key found */
	break;
      } else {
	current = current->next; 
      }
    }
  }
  /***** end find *****/

  if(table->key_count >= table->table_size && found == 0) {
    return FAILURE; /* if there are more keys than the size */
  }
  
  if(current == NULL) {  /* nothing there */
    current = malloc(sizeof(Bucket));
    current->key = malloc(sizeof(char) * (strlen(key) + 1));
    
    strcpy(current->key, key);
    current->value = value;
    current->next = NULL;
    table->buckets[hash_code(key) % size] = current;
    table->key_count++;
    
  } else if(found == 0) { /* add in front */
    k2 = malloc(sizeof(char) * (strlen(key) + 1));
    strcpy(k2, key);

    new_b = malloc(sizeof(Bucket));
    
    new_b->key = k2;
    new_b->value = value;
    new_b->next = table->buckets[hash_code(key) % size]->next;
    table->buckets[hash_code(key) % size] = new_b;
    table->key_count++;
    
  } else { /* key is found */
    if(table->free_value != NULL && current->value != NULL) {
      table->free_value(current->value);
      current->value = NULL;
      current->value = value;
    } else {
      value = NULL;
    }
  }
  
  return SUCCESS;
}

/* returns the value of given bucket */
int get_value(const Table *table, const char *key, void **value) {
  Bucket *current = NULL;
  int size = 0, found = 0;
  
  if(table == NULL || key == NULL) {
    return FAILURE;
  }

  size = table->table_size;
  
  if(table->buckets[hash_code(key) % size] != NULL) {
    current = table->buckets[hash_code(key) % size];

    while(current != NULL) {
      if(strcmp(current->key, key) == 0) {
	found = 1; /* key was found */
	break;
      } else {
	current = current->next; 
      }
    }
  }

  if(found == 1) {
    (*value) = current->value;
    return SUCCESS;
  } else { /*found == 0 */
    (*value) = NULL;
    return FAILURE;
  }
}


int get_key_count(const Table *table) {
  if(table == NULL) {
    return FAILURE;
  }
  return table->key_count;
}

/* removes bucket from table */
int remove_entry(Table *table, const char *key) {
  Bucket *current = NULL, *prev = NULL;
  int size = 0, found = 0;

  if(table == NULL || key == NULL) {
    return FAILURE;
  }

  size = table->table_size;
  
  if(table->buckets[hash_code(key) % size] != NULL) {
    current = table->buckets[hash_code(key) % size];

    while(current != NULL) {
      if(strcmp(current->key, key) == 0) {
	found = 1; /* key found */
	break;
      } else {
	current = current->next; 
      }
    }
  }
  if(current == NULL || found == 0) {
    return FAILURE; /* key was not found */
  }

  while( strcmp(current->key, key) != 0 ) { /* will never be NULL */
    prev = current;
    current = current->next;
  }

  if(prev != NULL) {
    prev->next = current->next;
  } else {
    table->buckets[hash_code(key) % size] = current->next;
  }
  free(current->key);
  current->key = NULL;
      
  if(table->free_value != NULL && current->value != NULL) {
    table->free_value(current->value);
  }
  current->value = NULL;
      
  free(current);
  current = NULL;

  table->key_count--;  
  return SUCCESS;
}

/* clear the table */
int clear_table(Table *table) {
  Bucket *current = NULL, *buck = NULL;
  int i = 0;

  if(table == NULL) {
    return FAILURE;
  }
  
  for(i = 0; i < table->table_size; i++) {
    if(table->buckets[i] != NULL) {
      current = table->buckets[i]; /* set current = head at that index */
    }

    while(current != NULL) {
      buck = current->next;
      free(current->key);
      current->key = NULL;
      
      if(table->free_value != NULL) {
	table->free_value(current->value);
	current->value = NULL;
      }
      
      
      free(current);
      current = NULL;
      current = buck;
    }

    table->buckets[i] = NULL;
  }
  table->key_count = 0;
  free(current);
  free(buck);  
  return SUCCESS;
}

/* returns success if the table is empty */
int is_empty(const Table *table) {

  if(table == NULL || table->key_count == 0) {
    return SUCCESS;
  }
  return 0;
}

/* returns the table size */
int get_table_size(const Table *table) {

  if(table == NULL) {
    return FAILURE;
  }
  return table->table_size; 
}

/* 
 * Do not modify this hash_code function.
 * Leave this function at the end of the file.
 * Do not add a prototype to the htable.h file
 * for this function.
 *
 */

unsigned int hash_code(const char *str) {
   unsigned int code;

   for (code = 0; *str; str++) {
      code ^= ((code << 3) | (code >> 29)) + (*str);
   }

   return code; 
}
