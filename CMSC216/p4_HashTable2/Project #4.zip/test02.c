#include <stdio.h>
#include <stdlib.h>
#include "htable.h"

int main(){
  Table *table_ptr;
  int x =2, table_size = 5;

  create_table(&table_ptr, table_size, NULL);

  put(table_ptr, "Peggy", &x);
  
  destroy_table(table_ptr);
  return 0;
}
