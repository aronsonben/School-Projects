#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "htable.h"
#include "my_memory_checker_216.h"

/*****************************************************/
/* In this file you will provide tests to your       */
/* hash table.  Each test should be named test1()    */
/* test2(), etc. Each test must have a description   */
/* of what it is testing (this description is really */
/* important).                                       */
/*                                                   */
/* You can tell whether any test failed if you       */
/* execute on the command line "echo $?" and you get */
/* a value other than 0. "echo $?" prints the status */
/* of the last command.                              */
/*                                                   */
/* main just calls all test1(), test2(), etc.        */
/*****************************************************/


/* Description here: This test checks ... that all memory
   created in create table is destroyed in destroy table.*/
static int test1() {
   int table_size = 2;
   Table *table_ptr;

   create_table(&table_ptr, table_size, free);
   destroy_table(table_ptr);

   return SUCCESS;
}

/* Testing create and destroy again, but with null free_value function */
static int test2() {
  int table_size = 2;
  Table *table_ptr;

  /* CURRENTLY CAUSING MEM LEAK */
  create_table(&table_ptr, table_size, NULL); 
  /*put(table_ptr, "Ben", &x);*/
  destroy_table(table_ptr);
  
   return SUCCESS;
}

/* testing get_table_size and is_empty */
static int test3() {
  Table *table_ptr;
  int table_size = 3;

  create_table(&table_ptr, table_size, NULL);
  if(get_table_size(table_ptr) != 3) return FAILURE;
  if(is_empty(table_ptr) == 0) return FAILURE;
  destroy_table(table_ptr);
  
  return SUCCESS;
}

/* testing put */
static int test4() {
  Table *table_ptr;
  int table_size = 3, x = 2;

  create_table(&table_ptr, table_size, NULL);
  put(table_ptr, "Ben", &x);
  destroy_table(table_ptr);
  
  return SUCCESS;
}

/* testing put and clear */ 
static int test5() {
  Table *table_ptr;
  int table_size = 4, val = 9;
  
  create_table(&table_ptr, table_size, NULL);
  put(table_ptr, "Key1", &val);  /* note: value is NULL */
  if(clear_table(table_ptr) == -1) return FAILURE;
  destroy_table(table_ptr);
  
  return SUCCESS;
}

/* testing put and get_key_count */
static int test6() {
  Table *table_ptr;
  int table_size = 3, y = 1;

  create_table(&table_ptr, table_size, NULL);
  put(table_ptr, "Rogue", &y);
  if(get_key_count(table_ptr) != 1) return FAILURE;
  destroy_table(table_ptr);

  return SUCCESS;
}

/* testing put and remove_entry and assuring the key count changes with them */
static int test7() {
  Table *table_ptr;
  int table_size = 3, val1 = 1;

  create_table(&table_ptr, table_size, NULL);
  put(table_ptr, "Key", &val1);
  if(get_key_count(table_ptr) != 1) return FAILURE; /* assure key count is 1 */
  if(remove_entry(table_ptr, "Key") == -1) return FAILURE;
  if(get_key_count(table_ptr) != 0) return FAILURE; /* assure key count is 0 */
  destroy_table(table_ptr);

  return SUCCESS;
}

/* testing if get_value works. note: passing in an int here */
static int test8() {
  Table *table_ptr;
  int table_size = 2, val1 = 1;
  void *v;

  create_table(&table_ptr, table_size, NULL);
  put(table_ptr, "Key 1", &val1);
  if(get_value(table_ptr, "Key 1", &v) != 1) return FAILURE;
  /*printf("Value of Key 1: %d\n", *(int *)v); how to print value */
  destroy_table(table_ptr);
  
  return SUCCESS;
}

/* testing clear_table after putting in multiple items, 
 * then make sure key count is correct */
static int test9() {
  Table *table_ptr;
  int table_size = 8, val1 = 1, val2 = 2;

  create_table(&table_ptr, table_size, NULL);
  put(table_ptr, "key1", &val1);
  put(table_ptr, "key2", &val2);
  clear_table(table_ptr);
  if(get_key_count(table_ptr) != 0) return FAILURE;
  destroy_table(table_ptr);
  
  return SUCCESS;
}

/* testing table_size again */
static int test10() {
  Table *table_ptr;
  int table_size = 8;

  create_table(&table_ptr, table_size, NULL);
  if(get_table_size(table_ptr) != 8) return FAILURE;
  destroy_table(table_ptr);
  
  return SUCCESS;
}

/* testing remove_entry with an int value */
static int test11() {
  Table *table_ptr;
  int table_size = 5, val1 = 2;

  create_table(&table_ptr, table_size, NULL);
  put(table_ptr, "key1", &val1);
  if(remove_entry(table_ptr, "k1") != -1) return FAILURE;
  destroy_table(table_ptr);

  return SUCCESS;
}

/* testing multiple puts and removes, then reassuring
 * key count is where it should be at after it all */
static int test12() {
  Table *tp;
  int size = 3, v1 = 8, v2 = 10, v3 = 1;

  create_table(&tp, size, NULL);
  put(tp, "Nelson", &v1);
  put(tp, "Benito", &v2);
  put(tp, "Gato", &v3);
  if(remove_entry(tp, "Benito") != 1) return FAILURE;
  if(remove_entry(tp, "Perro") != -1) return FAILURE; /*if key isn't in table*/
  remove_entry(tp, "Gato");
  if(get_key_count(tp) != 1) return FAILURE; /* key count should be 1 */
  destroy_table(tp);
  
  return SUCCESS;
}

/* testing put and remove with a free_value function */
static int test13() {
  Table *tp;
  int size = 2, val = 6;

  create_table(&tp, size, NULL); /* doesn't work with free */
  put(tp, "Benito", &val);
  if(remove_entry(tp, "Benito") != 1) return FAILURE;
  destroy_table(tp);

  return SUCCESS;
}

static int test14() {
  Table *tp;
  int size = 1;
  void *val;

  create_table(&tp, size, NULL); /* doesn't work with free */
  put(tp, "Benito", &val);
  destroy_table(tp);
  
  return SUCCESS;
}

static int test15() {
  Table *tp;
  int size = 100, val1 = 1;

  create_table(&tp, size, NULL);
  put(tp, "Ben", &val1);
  val1 = 10;
  if(put(tp, "Ben", &val1) != 1) {
    printf("Failed\n");
    return FAILURE;
  }
  /*printf("Value of Key 1: %d\n", val1); */
  destroy_table(tp);

  return SUCCESS;
}

static int test16() {
  Table *tp = NULL;
  int size = 100;
  const char *val = "l";

  create_table(&tp, size, free);
  put(tp, "h", &val);
  destroy_table(tp);

  /* i = 0;
  const char *str = "llllllllllllllllllllllllllllllllllllllllllllllllllllllllll";
  char *cur_key = NULL, *cur_val = NULL;

  create_table(&tp, size, free);
  for(i = 0; i < 100; i++) {
    cur_key = malloc(sizeof(char));
    *cur_key = i;
    cur_val = malloc(sizeof(char) * (strlen(str) + 1));
    strcpy(cur_val, str);
    if(put(tp, cur_key, cur_val)) {
      printf("can't put\n");
      return FAILURE;
    }
    if(destroy_table(tp) != 1) {
      printf("cant' destroy\n");
      return FAILURE;
    }
    free(cur_key);
    free(cur_val);
    }*/
  return SUCCESS;
}

int main() {
   int result = SUCCESS;

   /***** Starting memory checking *****/
   /*start_memory_check();*/
   /***** Starting memory checking *****/

   /* test1 */
   if(test1() == FAILURE) result = FAILURE;
   if(test1() == SUCCESS) printf("test1 SUCCEEDED\n");
   
   /* test2  */
   if(test2() == FAILURE) result = FAILURE;
   if(test2() == SUCCESS) printf("test2 SUCCEEDED\n");
   
   /* test3 */
   if(test3() == FAILURE) result = FAILURE;
   if(test3() == SUCCESS) printf("test3 SUCCEEDED\n");

   /* test4 */
   if(test4() == FAILURE) result = FAILURE;
   if(test4() == SUCCESS) printf("test4 SUCCEEDED\n");

   /* test5 */
   if(test5() == FAILURE) result = FAILURE;
   if(test5() == SUCCESS) printf("test5 SUCCEEDED\n");

   /* test6 */
   if(test6() == FAILURE) result = FAILURE;
   if(test6() == SUCCESS) printf("test6 SUCCEEDED\n");

   /* test7 */
   if(test7() == FAILURE) result = FAILURE;
   if(test7() == SUCCESS) printf("test7 SUCCEEDED\n");

   /* test8 */
   if(test8() == FAILURE) result = FAILURE;
   if(test8() == SUCCESS) printf("test8 SUCCEEDED\n");

   /* test9 */
   if(test9() == FAILURE) result = FAILURE;
   if(test9() == SUCCESS) printf("test9 SUCCEEDED\n");

   /* test10 */
   if(test10() == FAILURE) result = FAILURE;
   if(test10() == SUCCESS) printf("test10 SUCCEEDED\n");

   /* test11 */
   if(test11() == FAILURE) result = FAILURE;
   if(test11() == SUCCESS) printf("test11 SUCCEEDED\n");

   /* test12 */
   if(test12() == FAILURE) result = FAILURE;
   if(test12() == SUCCESS) printf("test12 SUCCEEDED\n");

   /* test13 */
   if(test13() == FAILURE) result = FAILURE;
   if(test13() == SUCCESS) printf("test13 SUCCEEDED\n");

   /* test14 */
   if(test14() == FAILURE) result = FAILURE;
   if(test14() == SUCCESS) printf("test14 SUCCEEDED\n");

   /* test15 */
   if(test15() == FAILURE) result = FAILURE;
   if(test15() == SUCCESS) printf("test15 SUCCEEDED\n");

   /* test16 */
   if(test16() == FAILURE) result = FAILURE;
   if(test16() == SUCCESS) printf("test16 SUCCEEDED\n");

   
   
   /****** Gathering memory checking info *****/
   /*stop_memory_check();*/
   /****** Gathering memory checking info *****/
   
   if(result == FAILURE) {
      exit(EXIT_FAILURE);
   }

   return EXIT_SUCCESS;
}

