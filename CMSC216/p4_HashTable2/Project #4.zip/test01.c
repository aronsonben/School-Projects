#include <stdio.h>
#include <stdlib.h>
#include "htable.h"

static void display_table(Table *table);
static void print_list(Bucket *bucket);

int main() {
   Table *table_ptr;
   int x, y, table_size = 5;
   void *value;

   create_table(&table_ptr, table_size, NULL);
   x = 2;
   put(table_ptr, "Peggy", &x);
   y = 1;
   put(table_ptr, "John", &y);

   get_value(table_ptr, "John", &value);
   printf("Value for John %d\n", *(int *) value);

   printf("Displaying Table\n");
   display_table(table_ptr);
   
   destroy_table(table_ptr);

   return 0;
}

static void display_table(Table *table) {
   int i;

   printf("Key_count: %d\n", table->key_count);
   printf("Table_size: %d\n", table->table_size);
   if (table->key_count == 0) {
      printf("Empty table\n");
   } else {
      for (i = 0; i < table->table_size; i++) {
         print_list(table->buckets[i]);
      }
   }
}

static void print_list(Bucket *bucket) {
   if (bucket != NULL) {
      printf("Key: %s, value: %d\n", bucket->key, *((int *) bucket->value));

      print_list(bucket->next);
   }
}
